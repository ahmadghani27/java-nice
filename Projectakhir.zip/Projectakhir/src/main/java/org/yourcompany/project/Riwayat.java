package org.yourcompany.project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;

public class Riwayat extends JFrame {

    private Font openSansFont;

    public Riwayat() {
        loadCustomFont();
        initComponents();
    }

    private void loadCustomFont() {
        try {
            openSansFont = Font.createFont(Font.TRUETYPE_FONT, new File("D:\\Github\\java-nice\\Projectakhir\\src\\main\\java\\org\\yourcompany\\project\\OpenSans-Regular.ttf")).deriveFont(24f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(openSansFont);
        } catch (FontFormatException | IOException e) {
            e.printStackTrace();
        }
    }

    private void initComponents() {
        JFrame jFrame1 = new JFrame();
        JButton jBinputID1 = new JButton();
        JPanel jPanel1 = new JPanel();
        JButton jBKeluar = new JButton();
        JLabel jLIDPLN2 = new JLabel();
        JScrollPane jScrollPane1 = new JScrollPane();
        JTable jTable1 = new JTable();
        JLabel jLtitle = new JLabel();

        jFrame1.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame1.setBackground(Color.WHITE);
        jFrame1.setFont(new Font("SansSerif", 0, 18));
        jFrame1.setForeground(new Color(0, 0, 51));
        jFrame1.setLocation(new Point(0, 0));
        jFrame1.getContentPane().setLayout(null);

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(640, 720));
        getContentPane().setLayout(null);

        jPanel1.setForeground(new Color(51, 0, 102));
        jPanel1.setLayout(null);

        jBKeluar.setBackground(Color.RED);
        jBKeluar.setFont(openSansFont); // Set custom font
        jBKeluar.setForeground(Color.WHITE);
        jBKeluar.setText("Menu Utama");
        jBKeluar.setBorder(javax.swing.BorderFactory.createLineBorder(Color.BLACK, 0));
        jBKeluar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jBKeluarActionPerformed(evt);
            }
        });
        jBKeluar.addActionListener(evt -> ActionMenu(evt));
        jPanel1.add(jBKeluar);
        jBKeluar.setBounds(290, 500, 210, 60);

        jLIDPLN2.setFont(openSansFont); // Set custom font
        jLIDPLN2.setHorizontalAlignment(SwingConstants.LEFT);
        jLIDPLN2.setText("ID PLN                :");
        jPanel1.add(jLIDPLN2);
        jLIDPLN2.setBounds(20, 10, 480, 60);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{
                    {null, null, null, null, null},
                },
                new String[]{
                    "No", "Paket", "Total Harga", "Status", "Tanggal"
                }
        ) {
            Class[] types = new Class[]{
                Integer.class, String.class, String.class, String.class, String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types[columnIndex];
            }

            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make the table non-editable
            }
        });

        jTable1.setColumnSelectionAllowed(true);
        jTable1.setRowHeight(28); // Set the row height to 28 pixels
        jTable1.setShowGrid(false); // Disable grid lines
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(0, 80, 520, 402);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(60, 90, 520, 610);

        jLtitle.setFont(openSansFont); // Set custom font
        jLtitle.setHorizontalAlignment(SwingConstants.CENTER);
        jLtitle.setText("Riwayat Transaksi");
        getContentPane().add(jLtitle);
        jLtitle.setBounds(80, 30, 470, 60);

        pack();
    }

    private void jBKeluarActionPerformed(ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void ActionMenu(ActionEvent evt) {
        MenuUtama menuUtama = new MenuUtama();
        menuUtama.setVisible(true);
        this.dispose();
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Riwayat().setVisible(true);
            }
        });
    }
}
