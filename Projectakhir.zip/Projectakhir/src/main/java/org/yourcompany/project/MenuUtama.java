package org.yourcompany.project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;

public class MenuUtama extends JFrame {

    private JButton jBBeli;
    private JButton jBKeluar;
    private JButton jBriwayat;
    private JFrame jFrame1;
    private JLabel jLIDPLN2;
    private JLabel jLNamaPengguna;
    private JLabel jLtitle;
    private JPanel jPanel1;
    private Font openSansFont;

    private static final String URL = "jdbc:mysql://localhost:3306/DataBaseIanKonter";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public MenuUtama() {
        loadCustomFont(); // Load the custom font
        initComponents();
        setResizable(false);
        Connector();
    }

    private void loadCustomFont() {
        try {
            openSansFont = Font.createFont(Font.TRUETYPE_FONT, new File("D:\\Github\\java-nice\\Projectakhir\\src\\main\\java\\org\\yourcompany\\project\\OpenSans-Regular.ttf")).deriveFont(24f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(openSansFont);
        } catch (FontFormatException | IOException e) {
            e.printStackTrace();
        }
    }

    private void initComponents() {
        jFrame1 = new JFrame();
        jPanel1 = new JPanel();
        jBKeluar = new JButton();
        jLNamaPengguna = new JLabel();
        jLIDPLN2 = new JLabel();
        jBBeli = new JButton();
        jBriwayat = new JButton();
        jLtitle = new JLabel();

        jFrame1.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jFrame1.setBackground(Color.WHITE);
        jFrame1.setFont(new Font("SansSerif", 0, 18));
        jFrame1.setForeground(new Color(0, 0, 51));
        jFrame1.setLocation(new Point(0, 0));
        jFrame1.setName("MainFrame");
        jFrame1.getContentPane().setLayout(null);

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(640, 720));
        getContentPane().setLayout(null);

        jPanel1.setForeground(new Color(51, 0, 102));
        jPanel1.setLayout(null);

        jBKeluar.setBackground(new Color(255, 0, 0));
        jBKeluar.setFont(openSansFont.deriveFont(32f)); // Use Open Sans font
        jBKeluar.setForeground(Color.WHITE);
        jBKeluar.setText("Keluar");
        jBKeluar.setBorder(null);
        jBKeluar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jBKeluarActionPerformed(evt);
            }
        });
        jPanel1.add(jBKeluar);
        jBKeluar.setBounds(290, 500, 210, 60);

        jLNamaPengguna.setFont(openSansFont.deriveFont(24f)); // Use Open Sans font
        jLNamaPengguna.setHorizontalAlignment(SwingConstants.LEFT);
        jLNamaPengguna.setText("Nama Pengguna :");
        jPanel1.add(jLNamaPengguna);
        jLNamaPengguna.setBounds(0, 60, 500, 60);

        jLIDPLN2.setFont(openSansFont.deriveFont(24f)); // Use Open Sans font
        jLIDPLN2.setHorizontalAlignment(SwingConstants.LEFT);
        jLIDPLN2.setText("ID PLN                : " );
        jPanel1.add(jLIDPLN2);
        jLIDPLN2.setBounds(0, 10, 500, 60);

        jBBeli.setBackground(Color.ORANGE);
        jBBeli.setFont(openSansFont.deriveFont(32f)); // Use Open Sans font
        jBBeli.setForeground(Color.WHITE);
        jBBeli.setText("Beli Token Listrik");
        jBBeli.setBorder(null);
        jBBeli.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jBBeliActionPerformed(evt);
            }
        });
        jBBeli.addActionListener(evt -> toPembelian(evt));
        jPanel1.add(jBBeli);
        jBBeli.setBounds(0, 150, 500, 130);

        jBriwayat.setBackground(new Color(13, 207, 0));
        jBriwayat.setFont(openSansFont.deriveFont(32f)); // Use Open Sans font
        jBriwayat.setForeground(Color.WHITE);
        jBriwayat.setText("Riwayat Transaksi");
        jBriwayat.setBorder(null);
        jBriwayat.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jBriwayatActionPerformed(evt);
            }
        });
        jBriwayat.addActionListener(evt -> toRiwayat(evt));
        jPanel1.add(jBriwayat);
        jBriwayat.setBounds(0, 300, 500, 130);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(60, 90, 520, 610);

        jLtitle.setFont(openSansFont.deriveFont(48f)); // Use Open Sans font
        jLtitle.setHorizontalAlignment(SwingConstants.CENTER);
        jLtitle.setText("Menu Utama");
        getContentPane().add(jLtitle);
        jLtitle.setBounds(80, 30, 470, 60);

        pack();
    }

    private void jBKeluarActionPerformed(ActionEvent evt) {
        MySQLConnector connector = new MySQLConnector();
        Connection connection = null;

        try {
            connection = connector.connect();
        } finally {
            connector.closeConnection(connection);
        }

        System.exit(0);
    }

    private void jBBeliActionPerformed(ActionEvent evt) {
    }

    private void jBriwayatActionPerformed(ActionEvent evt) {
    }

    public void Connector() {
        MySQLConnector connector = new MySQLConnector(); // Membuat instance dari MySQLConnector
        Connection connection = connector.connect(); // Memanggil metode connect
    }

    public void ID(String inputID) {
        String selectQuery = "SELECT * FROM id_pelanggan WHERE ID_Pelanggan = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD); PreparedStatement selectStmt = connection.prepareStatement(selectQuery)) {

            selectStmt.setString(1, inputID);
            ResultSet ID_Pelanggan = selectStmt.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void toPembelian(ActionEvent evt) {
        Pembayaran pembayaran = new Pembayaran();
        pembayaran.setVisible(true);
        this.dispose();
    }
    private void toRiwayat(ActionEvent evt) {
        Riwayat riwayat = new Riwayat();
        riwayat.setVisible(true);
        this.dispose();
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuUtama().setVisible(true);
            }
        });
    }
}